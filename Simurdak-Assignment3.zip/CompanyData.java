/* Hannah Simurdak
04/22/2019
CSCI 330 Assignment 1
*/

import java.util.*;

public class CompanyData {

  //Instance Variables
  private String ticker;
  private LinkedHashMap<String, String> splitD = new LinkedHashMap<>();
  private ArrayList<Prices> dayPrices = new ArrayList<Prices>();
  private int days = 0;
  private LinkedHashMap<String, Integer> DatesIndex = new LinkedHashMap<>();

  
  private LinkedHashMap<Integer, String> tickerStartDates = new LinkedHashMap<>();
  private LinkedHashMap<Integer, String> tickerEndDates = new LinkedHashMap<>();
  
//Add start date
 public void addStartDate(int interval, String date) {
	 tickerStartDates.put(interval, date);
 }
 
//Add end date
public void addEndDate(int interval, String date) {
	 tickerEndDates.put(interval, date);
}

// Get interval start date
public String getIntervalStartDate(int interval) {
	 return tickerStartDates.get(interval);
}
  
//Get interval end date
public String getIntervalEndDate(int interval) {
	 return tickerEndDates.get(interval);
}

  // Add DayPrice object to arrayList
  public void addDay(Prices curDay, String date) {
	  dayPrices.add(curDay);
	  DatesIndex.put(date, dayPrices.indexOf(curDay));
  }
  
  //return DayPrices
  public ArrayList<Prices> getDayPrices() {
	  return dayPrices;
  }
  
  // return Prices for specified date
  public Prices getPrices(String date) {
	  return dayPrices.get(DatesIndex.get(date));
  }

  //Constructor
  public CompanyData(String ticker) {
    this.ticker = ticker;
  }

  public String getCompany() {
    return ticker;
  }

  
  public void countDay() {
	  days++;
  }

  //add split days
  public void addSplitDay(String date, String info) {
    splitD.put(date, info);
  }

  public void getSplitDays() {
    int count = 0;


    for (Map.Entry<String, String> day : splitD.entrySet()) {
      System.out.println(day.getValue() + " split on " + day.getKey());
      count++;
    }
    System.out.println(count + " splits in " + days + " trading days\n");
  }
}
